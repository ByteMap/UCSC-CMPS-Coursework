public class thing2 extends Thing{
  thing2(String name){
    super(name);
      
  }
}