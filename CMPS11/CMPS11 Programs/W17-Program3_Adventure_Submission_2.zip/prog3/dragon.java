public class dragon extends Thing{
  dragon(String name){
    super(name);
  }
  
  boolean canBeCarried(){
    return false;
  }
  
}

