public class Sword extends Thing{
  Sword(){
    super("sword");
  }
  boolean broken = true; 
  int health = 5; 
  public void attack(){
    if(health == 0)
      System.out.println("The dragon is already weak, kill it already");
    else{
      health --; 
      System.out.println("You swing your sword");
      System.out.println("The dragon roars as your sword slashes its hide, dealing 1 damage to it. The dragon's health is now: " + health); 
      if(health == 0)
        System.out.println("The dragon's weak, here's your chance to kill it with your dagger!");
      
      
    }
  }
  
  public void repair(){
    if(broken == true){
      System.out.println("You have repaired your sword.");
      broken = false;
    }
    else{
      System.out.println("You don't need to repair your sword anymore.");
    }
  }
  
  
  
  
}
