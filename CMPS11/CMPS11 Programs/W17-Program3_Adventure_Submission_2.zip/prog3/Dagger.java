public class Dagger extends Thing{
  Dagger(){
    super("dagger");
  }
  
  public void kill(){
    System.out.println("Congratulations! You have slain the dragon!");
    System.out.println("Type quit to exit the game");
  }
}