public class Charlie extends Thing { 
  
  public Charlie(String name) {
    super(name);
  }
  
  public boolean canBeCarried() {
    return false; 
  }
 
}