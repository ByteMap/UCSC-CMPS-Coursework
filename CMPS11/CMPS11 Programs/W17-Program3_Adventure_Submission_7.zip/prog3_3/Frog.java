public class Frog extends Thing {  
  
  public Frog(String name) {
    super(name); 
  }
  
}