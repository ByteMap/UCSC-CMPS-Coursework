public class Sword extends Thing {  
  private String type;
  
  public Sword(String name) {
    super(name); 
  }
  
  public String toString() {
    return type;
  }
}