public class Mushroom extends Thing {  
  //private String type;
  
  public Mushroom(String name) {
    super(name); 
  }

}