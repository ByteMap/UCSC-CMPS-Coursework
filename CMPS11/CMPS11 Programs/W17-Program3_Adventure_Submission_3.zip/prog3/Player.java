import java.util.ArrayList;
/**
 * Representation of a Player moving around in an adventure game.
 * The player "knows" where s/he is and can carry items in a pack.
 */
public class Player {
  private ArrayList<Thing> pack = new ArrayList<Thing>();
  private Room location;
  private static final int MAX_THINGS = 3;
  private static final int MAX_HEALTH = 5;
  private int health = 5;
  private int damage = 2;
  public boolean hit(int hurt){
    health-=hurt;
    if(hurt!=0)
      System.out.println("Your health is now: "+health);
    return health<=0;
  }
  
  public ArrayList<Thing> getPack(){
    return pack;
  }
  
  public void heal(){
    health=MAX_HEALTH;
    System.out.println("Your health is now: "+health);
  }
  
  public int getDamage(){
    System.out.println("You hit the dragon for "+damage+" damage!");
    return damage;
  }
  
  public String toString() {
    StringBuffer result = new StringBuffer();
    for (Thing thing : pack) {
      result.append(thing.toString() + "\n");
    }
    result.append("Available capacity = " + (MAX_THINGS - pack.size()));
    return result.toString();
  }
  
  /**
   * Move this player to the specified room as long as the room is not null.
   * @param room to move to
   * @return true if the move was successful, false otherwise
   */
  boolean moveTo(Room room) {
    if (room != null) {
      location = room;
      return true;
    }
    else {
      return false;
    }
  }
  /**
   * @return the room the player is currently in.
   */
  Room getLocation() {
    return location;
  }
  
  /**
   * @param thing the player would like to add to the pack
   * @return true if the player can carry thing, false otherwise
   */
  boolean canCarry(Thing thing) {
    return (pack.size() < MAX_THINGS);
  }
  
  /**
   * Try and drop an item.
   * @param name of thing to drop
   * @return true if the player successfully dropped the thing, false otherwise
   */
  boolean drop(String name) {
    for (int i = 0; i < pack.size(); i++) {
      if (pack.get(i).name().equals(name)) {
        Thing item = pack.remove(i);
        location.add(item);
        return true;
      }
    }
    return false;
  }
  
  /**
   * Try and pickup an item.
   * @param name of the thing to pickup.
   * @return the Thing if it was successfully picked up, otherwise null
   */
  Thing pickup(String name) {
    if (location.contains(name)) {
      Thing thing = location.remove(name);
      if (canCarry(thing)) {
        if(thing.canBeCarried()){
          pack.add(thing); // got it
          return thing;
        }
        else{
          location.add(thing);
          System.out.println("put it back. That was too much.");
          return null;
        }
      }
      else {
        location.add(thing); // put it back. That was too much.
        System.out.println("You can't carry that. You may need to drop something first.");
        return null;
      }
    }
    else {
      return null; // it wasn't there to be picked up
    }
  }
  
  void destroy(Thing item){
    pack.remove(pack.indexOf(item));
  }
}