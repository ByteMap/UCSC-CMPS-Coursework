class Potion extends Thing{
  Potion(String name){
    super(name);
  }
  void use(Player player, Thing potion){
    System.out.println("You used the potion!");
    player.heal();
    player.destroy(potion);
  }
}