class Dragon extends Thing{
  private int health = 10;
  private int damage = 2;
  
  Dragon(String name){
    super(name);
  }
  
  public int getDamage(){
    if(health>0){
    System.out.println("The dragon hit you for "+damage+" damage!");
      return damage;
    }
    else return 0;
  }
  
  public boolean hit(int hurt){
    health-=hurt;
    System.out.println("The dragon's health is now: "+health);
    return health<=0;
  }
  
  boolean canBeCarried(){
    return false;
  }
}