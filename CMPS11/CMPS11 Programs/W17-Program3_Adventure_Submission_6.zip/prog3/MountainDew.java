
public class MountainDew extends Thing{
	public MountainDew() {
		super("Mountain Dew");
	}
	public String Drink() {
		String s = "You drink that sweet sweet gamer fuel";
		return s;
	}

}
