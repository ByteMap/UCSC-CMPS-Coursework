
public class EmptyBottle extends Thing{

	public EmptyBottle() {
		super("Empty Bottle");
	}
	
	public String Throw() {
		String s = "You throw the empty bottle with all your might";
		return s;
	}
}
