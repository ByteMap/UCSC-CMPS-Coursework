public class SwordTest {
    public static void swing() {
        Sword sword = new Sword("sword");
        System.out.println(sword);
    }
}