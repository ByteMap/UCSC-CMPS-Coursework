import javax.swing.*;
import java.awt.event.*;
/*class ActionsTwo implements ActionListener {
    private Player player;
    public ActionsTwo(Player player) {
        this.player = player;
    }
    public static void actionPerformed(ActionEvent e) {
        JTextField source = (JTextField)e.getSource();
        String text = source.getText();
        adventure.pickup(player, text);
    }
}*/