public class Sword extends Thing{
  Sword(){
    super("sword");
  }
  void swing(){
    System.out.println("You have swung your sword.");
  } 
}












