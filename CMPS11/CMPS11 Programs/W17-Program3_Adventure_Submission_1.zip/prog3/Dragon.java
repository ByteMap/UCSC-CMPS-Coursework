class Dragon extends Thing{
  Dragon(){
    super("dragon");
  }
  boolean canBeCarried() {
    return false;
  }
  
}



